package com.example.kaizenspeaking.ui.auth.data

data class AuthResponse(val data: User)


