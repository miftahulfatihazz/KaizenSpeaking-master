package com.example.kaizenspeaking.ui.instructions.data

data class OnboardingItem(
    val image: Int,
    val title: String,
    val description: String,
    val backgroundImage: Int,

    )
