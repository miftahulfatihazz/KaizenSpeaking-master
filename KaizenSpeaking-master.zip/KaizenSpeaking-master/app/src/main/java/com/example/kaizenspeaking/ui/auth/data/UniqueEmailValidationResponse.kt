package com.example.kaizenspeaking.ui.auth.data

class UniqueEmailValidationResponse(val isUnique: Boolean, val data: User)