package com.example.kaizenspeaking.ui.auth.data

data class LoginBody(val email: String, val password: String)
