package com.example.kaizenspeaking.ui.auth.data

data class  ValidateEmailBody(val email: String)
